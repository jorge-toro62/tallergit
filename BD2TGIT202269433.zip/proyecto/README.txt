Para realizar este git me base en el documento enviado por el profesor y mediante este, seguí el paso a paso para obtener el
resultado deseado por el docente.